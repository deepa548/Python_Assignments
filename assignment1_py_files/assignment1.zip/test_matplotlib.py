import numpy as np
import matplotlib.pyplot as plt
x=np.linspace(0,7,20)
y=np.linspace(0,9,20)



