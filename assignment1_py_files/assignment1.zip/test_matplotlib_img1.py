import numpy as np
import matplotlib.pyplot as plt
image=np.random.rand(30,30)

