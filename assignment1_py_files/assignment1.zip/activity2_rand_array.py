Python 3.9.5 (tags/v3.9.5:0a7dcbd, May  3 2021, 17:27:52) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> np.random.seed(10)
>>> z=np.random.rand(3)
>>> z
array([0.77132064, 0.02075195, 0.63364823])
>>> y=np.random.randn(3)
>>> y
array([-0.01002595,  1.67080819, -0.66437971])
>>> 