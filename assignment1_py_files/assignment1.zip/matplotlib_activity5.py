Python 3.9.5 (tags/v3.9.5:0a7dcbd, May  3 2021, 17:27:52) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
===================================== RESTART: C:/HI_Course/Sem4SoftwareEnggTechn/UI/assignment1_py_files/test_matplotlib_img1.py =====================================
>>> plt.imshow(image)
<matplotlib.image.AxesImage object at 0x000002199EFB9220>
>>> plt.show()
plt.imshow(image, cmap=plt.cm.Accent)
plt.imshow(image, cmap=plt.cm.hot)
plt.imshow(image, cmap=plt.cm.Pastel1)

plt.colorbar()

plt.show()
>>> plt.imshow(image, cmap=plt.cm.Accent)
<matplotlib.image.AxesImage object at 0x000002199CFE0610>
>>> plt.show()
>>> 